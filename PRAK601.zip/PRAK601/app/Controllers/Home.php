<?php

namespace App\Controllers;

use App\Models\profilModel;

class Home extends BaseController
{
    public function index()
    {
        $mahasiswa = new profilModel();
        return view('index', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
        ]);
    }
    public function biodata()
    {
        $mahasiswa = new profilModel();
        return view('biodata', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
            "citacita" => $mahasiswa->getcita_cita(),
            "alamat" => $mahasiswa->getAlamat(),
            "prodi" => $mahasiswa->getProdi(),
            "motivasi" => $mahasiswa->getMotivasi(),
            "hobi" => $mahasiswa->gethobi(),
            "foto" => $mahasiswa->getFoto()
        ]);
    }
}
