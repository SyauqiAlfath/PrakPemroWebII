<!DOCTYPE html>
<html>

<head>
    <title>Biodata Pribadi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
            background-repeat: no-repeat;
            background-image: url("../img/bg.jpg");
            background-size: cover;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            margin-top: 10px;
            background: #07182E;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-radius: 20px;
        }

        .container::before {
            content: '';
            position: absolute;
            width: 200px;
            background-image: linear-gradient(180deg, rgb(0, 183, 255), rgb(255, 48, 255));
            height: 270%;
            animation: rotBGimg 3s linear infinite;
            transition: all 0.2s linear;
        }

        @keyframes rotBGimg {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        .container::after {
            content: '';
            position: absolute;
            background: #07182E;
            ;
            inset: 5px;
            border-radius: 15px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            z-index: 1;
            color: white;
        }

        table {
            width: 100%;
            z-index: 1;
            color: white;
        }

        th,
        td {
            padding: 10px;
            text-align: left;

        }

        th {
            width: 30%;
        }

        .profile-img {
            width: 250px;
            height: 350px;
            border-radius: 10%;
            object-fit: cover;
            object-position: center;
            box-shadow: 7px 8px 19px -3px #A89D9D;
        }

        .btn-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        button {
            font-size: 1rem;
            padding: 0.4rem 1.2rem;
            border: none;
            outline: none;
            border-radius: 0.4rem;
            cursor: pointer;
            text-transform: uppercase;
            background-color: rgb(14, 14, 26);
            color: rgb(234, 234, 234);
            font-weight: 700;
            transition: 0.6s;
            box-shadow: 0px 0px 60px #1f4c65;
            -webkit-box-reflect: below 10px linear-gradient(to bottom, rgba(0, 0, 0, 0.0), rgba(0, 0, 0, 0.4));
        }

        button:active {
            scale: 0.92;
        }

        button:hover {
            background: rgb(2, 29, 78);
            background: linear-gradient(180deg, rgb(0, 183, 255), rgb(255, 48, 255));
            color: rgb(4, 4, 38);
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Biodata Pribadi</h1>

        <table>
            <tr>
                <!-- file foto masuk ke folder publid/img ... -->
                <td rowspan="8"><img src="<?= base_url('img/' . $foto) ?>" class="profile-img">
                </td>
                <th>Nama Lengkap</th>
                <td>
                    <?= $nama; ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td>
                    <?= $nim; ?>
                </td>
            </tr>
            <tr>
                <th>Asal Prodi</th>
                <td>
                    <?= $prodi; ?>
                </td>
            </tr>
            <tr>
            <tr>
                <th>Cita-cita</th>
                <td>
                    <?= $citacita; ?>
                </td>
            </tr>
            <tr>
                <th>Hobi</th>
                <td>
                    <?= $hobi; ?>
                </td>
            </tr>
            <tr>
                <th>Alamat</th>
                <td>
                    <?= $alamat; ?>
                </td>
            </tr>
            <th>Motto Hidup</th>
            <td>
                <?= $motivasi; ?>
            </td>
            </tr>
        </table>
    </div>
    <div class="btn-container">

        <form action="/home/index">
            <button>Beranda</button>
    </div>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>