<!DOCTYPE html>
<html>

<head>
    <title>Halaman Index</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-repeat: no-repeat;
            background-image: url("../img/bg.jpg");
            background-size: cover;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            margin-top: 100px;
            background: #07182E;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-radius: 20px;
        }

        .container::before {
            content: '';
            position: absolute;
            width: 150px;
            background-image: linear-gradient(180deg, rgb(0, 183, 255), rgb(255, 48, 255));
            height: 350%;
            animation: rotBGimg 3s linear infinite;
            transition: all 0.2s linear;
        }

        @keyframes rotBGimg {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        .container::after {
            content: '';
            position: absolute;
            background: #07182E;
            ;
            inset: 5px;
            border-radius: 15px;
        }


        .container h1 {
            z-index: 1;
            color: white;
            font-size: 2em;
            text-align: center;
            margin-bottom: 20px;

        }

        .container table {
            width: 100%;
            z-index: 1;
            color: #fff;
        }

        .container th,
        td {
            padding: 10px;
            text-align: left;
        }

        .container th {
            width: 30%;
        }

        .btn-container {
            display: flex;
            justify-content: center;
            z-index: 1;
        }

        button {
            font-size: 1rem;
            padding: 0.6rem 1.3rem;
            margin-top: 15px;
            border: none;
            outline: none;
            border-radius: 0.4rem;
            cursor: pointer;
            text-transform: uppercase;
            background-color: rgb(14, 14, 26);
            color: rgb(234, 234, 234);
            font-weight: 750;
            transition: 0.6s;
            box-shadow: 0px 0px 60px #1f4c65;
            -webkit-box-reflect: below 10px linear-gradient(to bottom, rgba(0, 0, 0, 0.0), rgba(0, 0, 0, 0.4));
        }

        button:active {
            scale: 0.92;
        }

        button:hover {
            background: #07182E;
            background: linear-gradient(180deg, rgb(0, 183, 255), rgb(255, 48, 255));
            color: rgb(4, 4, 38);
        }
    </style>

</head>

<body>
    <div class="container">
        <h1>Profile Mahasiswa</h1>
        <table>
            <tr>
                <th>Nama</th>
                <td>
                    <?= $nama ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td>
                    <?= $nim ?>
                </td>
            </tr>
        </table>
        <div class="btn-container">
            <form action="/home/biodata">
                <button>
                    Biodata
                </button>
            </form>
        </div>
    </div>
</body>

</html>