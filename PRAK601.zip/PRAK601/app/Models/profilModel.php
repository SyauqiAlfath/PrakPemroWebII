<?php

namespace App\Models;

use CodeIgniter\Model;

class profilModel extends Model
{
    protected $nama = "Muhammad Syauqi Al Fath";
    protected $nim = "2110817210020";
    protected $prodi = "Teknologi Informasi";
    protected $cita_cita = "Dokter";
    protected $hobi = "Renang, Futsal, dan Pingpong";
    protected $alamat = "Banjarmasin, Kalimantan Selatan";
    protected $motivasi = "Man Shobaro Zofiro";

    protected $foto = "Syauqi.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getcita_cita()
    {
        return $this->cita_cita;
    }
    public function gethobi()
    {
        return $this->hobi;
    }
    public function getAlamat()
    {
        return $this->alamat;
    }
    public function getMotivasi()
    {
        return $this->motivasi;
    }
    public function getFoto()
    {
        return $this->foto;
    }
}
